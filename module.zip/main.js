/************************************************************
 * Xeno-Malice Unified Module v3.1.0
 * - Xenoticダメージタイプ登録
 * - 神オーラへXenoticだけを転送
 * - PCが与えたXenoticダメージを特徴「XenoticPoint」の使用回数として蓄積
 ************************************************************/

console.log("🧪 [Xeno-Malice] Unified Module v3.1.0 loaded");

// 1) Xenotic ダメージタイプ登録
Hooks.once("init", () => {
  console.log("🧬 [Xeno-Malice] Registering Xenotic damage type");
  CONFIG.DND5E.damageTypes["xenotic"] = "Xenotic";
  CONFIG.DND5E.damageResistanceTypes["xenotic"] = "Xenotic";
  CONFIG.DND5E.damageVulnerabilityTypes["xenotic"] = "Xenotic";
  CONFIG.DND5E.damageImmunityTypes["xenotic"] = "Xenotic";
});

// 2) Ready ログ
Hooks.once("ready", () => {
  console.log("⚔️ [Xeno-Malice] Ready — DamageRollComplete active");
});

// 3) Xenotic 処理本体
Hooks.on("midi-qol.DamageRollComplete", async (workflow) => {
  console.log("🜂 [Xeno-Malice] DamageRollComplete triggered");

  const attacker = workflow.actor;
  const targetToken = workflow.hitTargets?.first?.() ?? workflow.targets?.first?.();
  if (!targetToken) return;
  const defender = targetToken.actor;
  if (!defender) return;

  // --- ダメージ集計 ---
  let xenoticTotal = 0;
  let normalTotal = 0;
  const normalDetails = [];

  for (const d of workflow.damageDetail) {
    const dmgType = String(d.type ?? "").toLowerCase();
    if (dmgType === "xenotic") {
      xenoticTotal += d.value ?? d.damage ?? 0;
    } else {
      normalTotal += d.value ?? d.damage ?? 0;
      normalDetails.push(d);
    }
  }

  // Xenoticダメージが無ければ何もしない
  if (xenoticTotal <= 0) return;

  //==============================
  // ✦ 追加要素 ✦ XenoticPoint蓄積（PCのみ）
  //==============================
  if (attacker?.type === "character") {
    console.log(`⚛ [Xeno-Malice] PC dealt ${xenoticTotal} Xenotic`);

    // 名前に「XenoticPoint」を含む特徴アイテムを探す
    const xenoticItem = attacker.items.find((item) => {
      const name = (item.name ?? "").toLowerCase();
      return name.includes("xenoticpoint") || name.includes("xenotic point");
    });

    if (!xenoticItem) {
      console.warn("⚠ [Xeno-Malice] Feature 'XenoticPoint' not found on attacker");
    } else {
      const uses = xenoticItem.system?.uses;
      if (!uses) {
        console.warn("⚠ [Xeno-Malice] 'XenoticPoint' has no uses field");
      } else {
        const current = uses.value ?? 0;
        const max = uses.max ?? null;
        let newValue = current + xenoticTotal;

        // 上限が設定されているならクランプしておく
        if (max !== null && max !== undefined) {
          newValue = Math.min(newValue, max);
        }

        await xenoticItem.update({ "system.uses.value": newValue });

        console.log(
          `📈 [Xeno-Malice] XenoticPoint uses ${current} → ${newValue}` +
          (max != null ? ` / ${max}` : "")
        );
      }
    }
  }

  //==============================
  // ✦ 既存要素 ✦ オーラへの転送処理
  //==============================
  const auraId = await defender.getFlag("world", "auraId");
  if (!auraId) return;

  const auraActor = game.actors.get(auraId);
  if (!auraActor) return;
  const auraToken = auraActor.getActiveTokens()[0];
  if (!auraToken) return;

  // Defender側には通常ダメージだけ残す
  workflow.damageDetail = normalDetails;
  workflow.damageTotal = normalTotal;

  try {
    await MidiQOL.applyTokenDamage(
      [{ damage: xenoticTotal, type: "xenotic" }],
      xenoticTotal,
      new Set([auraToken]),
      workflow.item,
      new Set(),
      { flavor: "Xenotic" }
    );
    console.log(`➡ [Xeno-Malice] Xenotic transferred to Aura (${xenoticTotal})`);
  } catch (e) {
    console.error("❌ [Xeno-Malice] Aura damage error:", e);
  }
});
